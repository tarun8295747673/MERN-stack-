const ResponseHandler = (success, data, message) =>{
    return({
        success, 
        data,
        message
    })
}

module.exports = {
    ResponseHandler
}